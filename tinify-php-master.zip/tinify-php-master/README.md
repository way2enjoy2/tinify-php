[<img src="https://travis-ci.org/tinify/tinify-php.svg?branch=master" alt="Build Status">](https://travis-ci.org/tinify/tinify-php)

# Way2enjoy API client for PHP

PHP client for the Way2enjoy API, used for [TinyPNG](https://way2enjoy.com) and [TinyJPG](https://tinyjpg.com). Way2enjoy compresses your images intelligently. Read more at [http://way2enjoy.com](http://way2enjoy.com).

## Documentation

[Go to the documentation for the PHP client](https://way2enjoy.com/developers/reference/php).

## Installation

Install the API client with Composer. Add this to your `composer.json`:

```json
{
  "require": {
    "way2enjoy/way2enjoy": "*"
  }
}
```

Then install with:

```
composer install
```

Use autoloading to make the client available in PHP:

```php
require_once("vendor/autoload.php");
```

## Usage

```php
Way2enjoy\setKey("YOUR_API_KEY");
Way2enjoy\fromFile("unoptimized.png")->toFile("optimized.png");
```

## Running tests

```
composer install
vendor/bin/phpunit
```

### Integration tests

```
composer install
TINIFY_KEY=$YOUR_API_KEY vendor/bin/phpunit --no-configuration test/integration.php
```

## License

This software is licensed under the MIT License. [View the license](LICENSE).
